package com.taobao.app;

public class Tools {
	
	public  static String getSearchUrl(String key,int page ){	
		return "http://search1.wap.taobao.com/s/search.htm?vm=nw&search_wap_mall=false&n=10&q="+key+"&page="+page;
	}
	public static boolean isEmpty(String str){
		if(null == str||"".equals(str))
			return true;
		else
		    return false;
	}
}
