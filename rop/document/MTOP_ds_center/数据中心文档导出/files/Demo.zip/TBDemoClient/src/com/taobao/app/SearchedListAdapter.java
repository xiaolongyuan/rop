package com.taobao.app;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.os.Handler.Callback;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.SimpleAdapter.ViewBinder;

public class SearchedListAdapter extends SimpleAdapter implements Runnable,
		ViewBinder, Callback {
	public static final int SEARCHEDITEM_IS_NULL = 201;

	private static final String PRD_DETAIL_URL = "auctionURL";
	private static final String TOTAL_NUM = "totalResults";
	private static final String ITEMS_ARRAY = "itemsArray";
	private static final String PRD_TITLE = "title";
	private static final String PRD_PRICE = "price";
	private static final String PRD_AREA = "location";
	private static final String PRD_SELLED = "sold";
	private static final String PRD_CREDIT = "ratesum";
	private static final String PRD_CREDIT_PIC = "credit_pic";
	private static final String PRD_USER_TYPE = "userType";
	private static final String ITEM_ID = "item_id";
	private static final String USER_TYPE_C = "0";
	private static final String PRD_USER_TYPE_PIC = "userType_pic";
	private static final String PRD_PICURL = "pic_path";
	private static final String PRD_PIC = "pic";
	private static final String MAP_PTR = "map_ptr";
	
	private Thread imgDLThread;
	private boolean finish = false;
	private ArrayList<HashMap<String, Object>> data;
	private Bitmap mall = null;
	private Bitmap DLBmp = null;
	private int loadedItemId = 0;
	private int pageSize = 10;
	private int totalNum = 0;
	private int totalPage = 0;
	private int currentPage = 1;
	private Context context;
	private Handler Apphandler;
	private Handler handler;

	public SearchedListAdapter(Context context,
			ArrayList<HashMap<String, Object>> data, Handler handler) {
		super(context, data, R.layout.search_item, new String[] { PRD_PIC,
				PRD_TITLE, PRD_SELLED, PRD_CREDIT_PIC, PRD_PRICE, PRD_AREA,
				PRD_USER_TYPE_PIC }, new int[] { R.id.goods_img,
				R.id.title_txt, R.id.selled_num, R.id.credit_img,
				R.id.price_value, R.id.area_txt, R.id.usertype_img });

		this.context = context;
		Apphandler = handler;
		this.handler = new Handler(this);

		// �󶨹�����TEXTVIEW���Զ�����������ͼƬ��Ҫ�ֶ�����
		this.setViewBinder(this);

		mall = drawableToBitmap(context.getResources().getDrawable(
				R.drawable.mall));
		DLBmp = drawableToBitmap(context.getResources().getDrawable(
				R.drawable.download));
		this.data = data;
	}

	void startDownLoadListItemImg() {
		if (imgDLThread != null) {
			imgDLThread.destroy();
		}
		imgDLThread = null;

		imgDLThread = new Thread(this);
		imgDLThread.setDaemon(true);
		imgDLThread.start();
	}

	@Override
	public void run() {
		InputStream is = null;
		HttpURLConnection httpConn = null;
		boolean downloadFail = false;
		while (!finish || data.size() > loadedItemId) {
			// �ж��Ƿ���item��ͼƬû����
			if (data.size() > loadedItemId) {
				String url_str = null;
				try {
					// ����ͼƬ ֪ͨ���̸߳����ƶ���item listviewֻ�������̸߳���
					HashMap<String, Object> map = null;
					URL url = null;
					synchronized (this) {// ͬ�� ��ֹ�����ݱ���� ��ͼƬ�����߳�֮���ͬ��
						if (data.size() > loadedItemId) {
							map = data.get(loadedItemId++);
							url_str = (String) map.get(PRD_PICURL);
							if (url_str != null)
								url = new URL(url_str.replace("_60x60.jpg",
										"_80x80.jpg"));
						}
					}
					if (url_str == null) {
						try {
							Thread.sleep(50);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						continue;
					}

					httpConn = (HttpURLConnection) url.openConnection();
					httpConn.setDoInput(true);
					httpConn.setConnectTimeout(5000);// TIMEOUT);
					httpConn.setReadTimeout(5000);// TIMEOUT);
					httpConn.connect();
					is = httpConn.getInputStream();

					if (is == null) {
						continue;
					}

					HashMap<String, Object> buf = new HashMap<String, Object>();
					buf.put(PRD_PIC, getRoundedCornerBitmap(new BitmapDrawable(
							is).getBitmap()));
					buf.put(MAP_PTR, map);

					// ���سɹ�����յ�ַ
					Message msg = new Message();
					msg.obj = buf;
					// public static final int MSG_EDITITEM = 2;//����item�������
					// ����ͼƬ���Ӷ���
					msg.what = 2;// WebDummyAdapter.MSG_EDITITEM;
					handler.sendMessage(msg);

					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

				} catch (Exception e) {
					Log.e("load��imageError", "cannot load the picture:"
							+ url_str);
					downloadFail = true;
				} finally {
					if (httpConn != null) {
						httpConn.disconnect();
						httpConn = null;
					}
					try {
						if (is != null)
							is.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} else {
				if (downloadFail) {
					downloadFail = false;
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		imgDLThread.destroy();
	}

	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
		if (bitmap == null)
			return null;
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = 5;

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}

	@Override
	public boolean handleMessage(Message msg) {
		if (2 == msg.what) {
			HashMap<String, Object> map = (HashMap<String, Object>) msg.obj;
			if (!data.isEmpty()) {
				HashMap<String, Object> tmp = (HashMap<String, Object>) map
						.get(MAP_PTR);
				if (data.contains(tmp)) {
					tmp.put(PRD_PIC, map.get(PRD_PIC));
					tmp.put(PRD_PICURL, null);
					notifyDataSetChanged();
				} else {
					Bitmap bitmap = (Bitmap) map.get(PRD_PIC);
					if (bitmap != null)
						bitmap.recycle();
				}
			}
			map.clear();
			return true;
		}
		return false;
	}

	@Override
	public boolean setViewValue(View view, Object data,
			String textRepresentation) {
		boolean ret = false;
		if (view.getId() == R.id.goods_img) {
			if (data != null){
				((ImageView) view).setImageBitmap((Bitmap) data);
			}
			ret = true;
		} else if (view.getId() == R.id.title_txt) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((TextView) view).setText((String) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		} else if (view.getId() == R.id.selled_num) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((TextView) view).setText((String) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		} else if (view.getId() == R.id.credit_img) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((ImageView) view).setImageDrawable((Drawable) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		} else if (view.getId() == R.id.price_value) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((TextView) view).setText((String) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		} else if (view.getId() == R.id.area_txt) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((TextView) view).setText((String) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		} else if (view.getId() == R.id.usertype_img) {
			if (data == null) {
				view.setVisibility(View.GONE);
			} else {
				((ImageView) view).setImageBitmap((Bitmap) data);
				view.setVisibility(View.VISIBLE);
			}
			ret = true;
		}
		return ret;
	}

	// �������б�������������
	public void addSearchedDate2Items(Vector<?> v) {
		if (v != null) {
			for (int i = 0; i < v.size(); i++) {
				Map<String, String> tempData = (Map<String, String>) v.get(i);
				HashMap<String, Object> item = new HashMap<String, Object>();

				item.put(PRD_PICURL, tempData.get(PRD_PICURL));
				item.put(PRD_TITLE, tempData.get(PRD_TITLE));
				item.put(PRD_PIC, null);
				item.put(PRD_PIC, DLBmp);

				if (tempData.get(PRD_AREA) == null) {
					item.put(PRD_AREA, null);
				} else {
					item.put(PRD_AREA, tempData.get(PRD_AREA));
				}

				if (tempData.get(PRD_SELLED) == null) {
					item.put(PRD_SELLED, null);
				} else {
					item.put(PRD_SELLED, tempData.get(PRD_SELLED));
				}

				if (tempData.get(PRD_CREDIT) == null) {
					item.put(PRD_CREDIT_PIC, null);
				} else {
					int iTempPicID = GetCREDIT_PIC(Integer.parseInt(tempData
							.get(PRD_CREDIT)));
					if (iTempPicID == 0) {
						item.put(PRD_CREDIT_PIC, null);
					} else {
						item.put(PRD_CREDIT_PIC, null);
						item.put(PRD_CREDIT_PIC, context.getResources()
								.getDrawable(iTempPicID));
					}

				}

				if (tempData.get(PRD_PRICE) == null) {
					item.put(PRD_PRICE, null);
				} else {
					item.put(PRD_PRICE, tempData.get(PRD_PRICE));
				}

				if (!USER_TYPE_C.equals(tempData.get(PRD_USER_TYPE))) {
					item.put(PRD_USER_TYPE_PIC, null);
					item.put(PRD_USER_TYPE_PIC, mall);
				} else {
					item.put(PRD_USER_TYPE_PIC, null);
				}

				// ��ƷID
				if (tempData.get(ITEM_ID) == null) {
					item.put(ITEM_ID, null);
				} else {
					item.put(ITEM_ID, tempData.get(ITEM_ID));
				}

				this.data.add(item);
				tempData.clear();
			}
			v.clear();
		}

	}

	public int GetCREDIT_PIC(int rateSum) {
		if (rateSum == 1)
			return R.drawable.s_red_1;

		else if (rateSum == 2)
			return R.drawable.s_red_2;

		else if (rateSum == 3)
			return R.drawable.s_red_3;

		else if (rateSum == 4)
			return R.drawable.s_red_4;

		else if (rateSum == 5)
			return R.drawable.s_red_5;

		else if (rateSum == 6)
			return R.drawable.s_blue_1;

		else if (rateSum == 7)
			return R.drawable.s_blue_2;

		else if (rateSum == 8)
			return R.drawable.s_blue_3;

		else if (rateSum == 9)
			return R.drawable.s_blue_4;

		else if (rateSum == 10)
			return R.drawable.s_blue_5;

		else if (rateSum == 11)
			return R.drawable.s_cap_1;

		else if (rateSum == 12)
			return R.drawable.s_cap_2;

		else if (rateSum == 13)
			return R.drawable.s_cap_3;

		else if (rateSum == 14)
			return R.drawable.s_cap_4;

		else if (rateSum == 15)
			return R.drawable.s_cap_5;

		else if (rateSum == 16)
			return R.drawable.s_crown_1;

		else if (rateSum == 17)
			return R.drawable.s_crown_2;

		else if (rateSum == 18)
			return R.drawable.s_crown_3;

		else if (rateSum == 19)
			return R.drawable.s_crown_4;

		else if (rateSum == 20)
			return R.drawable.s_crown_5;

		return 0;
	}

	public static Bitmap drawableToBitmap(Drawable drawable) {

		Bitmap bitmap = Bitmap
				.createBitmap(
						drawable.getIntrinsicWidth(),
						drawable.getIntrinsicHeight(),
						drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888
								: Bitmap.Config.RGB_565);
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
				drawable.getIntrinsicHeight());
		drawable.draw(canvas);
		return bitmap;
	}

	// ���������Ľ��
	public Object searchedDataAnalysis(byte[] all) {
		Vector<Map<String, String>> vector = new Vector<Map<String, String>>();
		try {
			String str = new String(all, "UTF-8");
			Log.v("SearchedDataAnalysis start...\n", str);

			if (str.length() != 0) {
				JSONObject jsObj = new JSONObject(str);
				if (jsObj.has(TOTAL_NUM)){
					setTotalNum(Integer.parseInt(jsObj.getString(TOTAL_NUM)));
				}
				if (jsObj.has(ITEMS_ARRAY)) {
					JSONArray array = jsObj.getJSONArray(ITEMS_ARRAY);
					// �����˵�б�Ϊ0
					if (array.length() == 0) {
						Apphandler.sendEmptyMessage(SEARCHEDITEM_IS_NULL);
						return null;
					}

					for (int i = 0; i < array.length() && i < pageSize; i++) {
						JSONObject item = array.getJSONObject(i);
						Map<String, String> data = new HashMap<String, String>();
						// ����
						if (item.has(PRD_TITLE)) {
							String title = item.getString(PRD_TITLE);
							title = title.replaceAll("\r\n", " ");
							title = title.replaceAll("\n", " ");
							title = title.replaceAll("\r", " ");
							data.put(PRD_TITLE, title);
						}
						// �۸�
						if (item.has(PRD_PRICE))
							data.put(PRD_PRICE, item.getString(PRD_PRICE));

						// ͼƬ��ַ
						if (item.has(PRD_PICURL))
							data.put(PRD_PICURL, item.getString(PRD_PICURL));
						// ����
						if (item.has(PRD_AREA))
							data.put(PRD_AREA, item.getString(PRD_AREA));
						// �۳���
						if (item.has(PRD_SELLED))
							data.put(PRD_SELLED, item.getString(PRD_SELLED));
						// // ����
						if (item.has(PRD_CREDIT))
							data.put(PRD_CREDIT, item.getString(PRD_CREDIT));

						if (item.has(PRD_USER_TYPE))
							data.put(PRD_USER_TYPE,
									item.getString(PRD_USER_TYPE));

						if (item.has(PRD_DETAIL_URL))
							data.put(PRD_DETAIL_URL,
									item.getString(PRD_DETAIL_URL));

						// ��ƷID
						if (item.has(ITEM_ID))
							data.put(ITEM_ID, item.getString(ITEM_ID));

						vector.add(data);
					}
					addCurrentPage(1);
				} else {
					vector = null;
				}

			} else {
				vector = null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			vector = null;
		}
		return vector;
	}

	// ������������
	public void setTotalNum(int totalNum) {

		if (totalNum > 1000) {
			totalNum = 1000;
		}

		this.totalNum = totalNum;
		// ������ҳ��
		if (pageSize != 0){
			if (totalNum % pageSize == 0){
				setTotalPage(totalNum / pageSize);
			}else{
				setTotalPage(totalNum / pageSize + 1);
			}
		}
			
		if (totalNum == 0){
			setFinshed(true);
		}
	}

	public void addCurrentPage(int step) {
		if (totalPage != 0) {
			if (totalPage < currentPage + step) {
				currentPage = totalPage;
				setFinshed(true);
			} else {
				currentPage += step;
			}
		} else{
			currentPage += step;
		}
		
		if (currentPage >= totalPage){
			setFinshed(true);
		}
	}

	// ������ҳ��
	public void setTotalPage(int totalPage) {
		// ��ҳ��������100ҳ
		if (totalPage > 100){
			totalPage = 100;
		}
		this.totalPage = totalPage;
	}

	// ����
	public void setFinshed(boolean finshed) {
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public int getPageSize() {
		return totalNum;
	}

	@Override
	public Object getItem(int index) {
		return data.get(index);
	}

}