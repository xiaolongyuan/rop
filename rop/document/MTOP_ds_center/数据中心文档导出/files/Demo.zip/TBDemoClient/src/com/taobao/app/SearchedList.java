package com.taobao.app;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.os.Handler.Callback;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

public class SearchedList extends Activity implements Callback {

	private static final int PAGE_CAPACITY = 20;
	private static final String ITEM_ID = "item_id";
	private int pageOffset = 0;
	private HttpEngine httpEngine;
	private ListView searchedList;
	private SearchedListAdapter searchedListadapter;
	private ArrayList<HashMap<String, Object>> m_SearchedListdata;
	private TextView searchedListTotlePage;
	private TextView searchedListCurrentPage;
	private String SearchedKey = null;
	private ImageView httpErrorImg;
	Handler Apphandler = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.searchlist);

		Apphandler = new Handler(this);
		searchedList = (ListView) findViewById(R.id.searchedlist);
		searchedListTotlePage = (TextView) this.findViewById(R.id.num2);
		searchedListCurrentPage = (TextView) this.findViewById(R.id.num1);
		httpErrorImg = (ImageView) this.findViewById(R.id.httpErrorImg);

		// ��ʼ��HTTP
		httpEngine = new HttpEngine();
		httpEngine.getHttpClient();
		m_SearchedListdata = new ArrayList<HashMap<String, Object>>();

		// !(ע:���ǿͻ��˴˴�2�пɺϳ�һ������ʱ����tempSearchedDate������)
		// �ֿ�Ϊ��ÿ�����ִ��һ�����ܣ������Ķ�
		// ��ȡ�������
		Bundle bundle = this.getIntent().getExtras();
		SearchedKey = bundle.getString("SEARCHED_KEY");// ����
		SearchedKey = URLEncoder.encode(SearchedKey);
		String SearchedListUrl = Tools.getSearchUrl(SearchedKey, 1);
		String temp_SearchedDate = httpEngine.doGet(SearchedListUrl);
		searchedListadapter = new SearchedListAdapter(this, m_SearchedListdata,
				Apphandler);

		// ����
		// ���Ż�������д�����ݿ⣬�´��������Щ��Ϣ�Ͳ�������������
		Object temp_SearchedDataObj = searchedListadapter
				.searchedDataAnalysis(temp_SearchedDate.getBytes());
		if (temp_SearchedDataObj == null) {
			httpErrorImg.setVisibility(View.VISIBLE);
			return;
		}
		searchedListadapter
				.addSearchedDate2Items((Vector<?>) temp_SearchedDataObj);
		searchedList.setAdapter(searchedListadapter);

		// ���õײ���ҳ�루����1/168ҳ��
		if (searchedListTotlePage.getText().toString().equals(" ")
				|| searchedListTotlePage.getText().toString().equals(" ")) {
			int TotalResult = searchedListadapter.getTotalNum();
			if (TotalResult <= 0) {
				searchedListCurrentPage.setText("0");
			} else {
				searchedListCurrentPage.setText("1");
			}
			searchedListTotlePage.setText("/"
					+ Integer.toString((TotalResult + 9) / 10) + "ҳ");
		} else if (searchedListadapter.getCurrentPage() <= 2) {
			int TotalResult = searchedListadapter.getTotalNum();
			if (TotalResult <= 0) {
				searchedListCurrentPage.setText("0");
			} else {
				searchedListCurrentPage.setText("1");
			}
			searchedListTotlePage.setText("/"
					+ Integer.toString((TotalResult + 9) / 10) + "ҳ");
		}

		searchedList.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				if (!searchedListCurrentPage.getText().toString().equals(" ")) {
					if (!searchedListTotlePage.getText().toString()
							.equals("/0ҳ")) {
						searchedListCurrentPage.setText(Integer
								.toString((firstVisibleItem + visibleItemCount) / 10 + 1));
					} else {
						searchedListCurrentPage.setText("0");
					}
				}

				if (searchedListadapter.getCount() < searchedListadapter
						.getTotalNum())
					if (firstVisibleItem + visibleItemCount >= totalItemCount) {
						// ��Ҫ����������
						if (pageOffset + PAGE_CAPACITY >= searchedListadapter
								.getCurrentPage() - 1) {

							// ��������PAGE_CAPACITY
							// ��Ҫɾ��
							if (pageOffset + PAGE_CAPACITY == searchedListadapter
									.getCurrentPage() - 1) {
								pageOffset++;
								for (int i = 0; i < searchedListadapter
										.getPageSize(); i++) {
									// �������� ����list���Ƴ�
									m_SearchedListdata.remove(0);
								}

								// �ж�ListView UI�Ƿ�ˢ�����,�����SetSelection
								if (searchedListadapter.getCount() == totalItemCount
										- ((ListView) view)
												.getFooterViewsCount()) {
									searchedList
											.setSelection(searchedListadapter
													.getPageSize()
													* (PAGE_CAPACITY - 1));
								}

							}
							// ������һ��ҳ��
							downLoadNextPage();
						}
					} else if (firstVisibleItem <= 0 && pageOffset > 0) {
						pageOffset--;
						searchedList.setSelection(searchedListadapter
								.getPageSize());
					}
			}

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
			}
		});
		searchedList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long id) {
				if (id == -1) {
					if (pageOffset + PAGE_CAPACITY == searchedListadapter
							.getCurrentPage() - 1) {
						// ��������PAGE_CAPACITY
						// ��Ҫɾ��
						pageOffset++;
					}
				} else if (id >= 0) {
					Map<String, Object> map = (Map<String, Object>) m_SearchedListdata
							.get((int) id);
					if (map != null && map.containsKey(ITEM_ID)) {
						String strDetailItemID = (String) map.get(ITEM_ID);

						try {
							String strTks = "";
							
							if(TBGlobalContext.getInstance().getPlatformService() != null)
								TBGlobalContext.getInstance().getPlatformService().doRequest(
											"api=com.taobao.android.platformservice&action=detail&appuid="
													+ TBGlobalContext
															.getInstance()
															.getAppUID()
													+ "&data={\"itemid\":\""
													+ strDetailItemID
													+ "\", \"tks\":\"" + strTks
													+ "\"}");

						} catch (RemoteException e) {
							e.printStackTrace();
							return;
						}

					}
				}
			}
		});

		// ����ͼƬ
		searchedListadapter.startDownLoadListItemImg();
	}

	private void downLoadNextPage() {
		String SearchedListUrl = Tools.getSearchUrl(SearchedKey,
				searchedListadapter.getCurrentPage());
		Log.v("downLoadNextPage", SearchedListUrl);
		String temp_SearchedDate = httpEngine.doGet(SearchedListUrl);
		Object temp_SearchedDataObj = searchedListadapter
				.searchedDataAnalysis(temp_SearchedDate.getBytes());

		searchedListadapter
				.addSearchedDate2Items((Vector<?>) temp_SearchedDataObj);
	}

	@Override
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case SearchedListAdapter.SEARCHEDITEM_IS_NULL: {
			Dialog dialog = new AlertDialog.Builder(this)
					.setTitle("��ʾ")
					.setMessage("�Բ���û��������صı�����")
					.setPositiveButton("ȷ��",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									finish();
								}
							}).create();
			dialog.setCancelable(false);
			dialog.show();
			return true;
		}
		}
		return false;
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
}
