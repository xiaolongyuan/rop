package com.taobao.app;

import android.app.Activity;

import com.taobao.platformservice.ITBPlatformService;


/**
 * ----------------------------------------------------------------------------------------------
*
* Copyright ? 2003-2011 Taobao.com 
* This file is Taobao property. Taobao ��s trade secret, proprietary and 
* confidential information is contained in this file.
* The information and code contained in this file is only for authorized
* Taobao employees to design, create, modify, or review.
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
* You shall not disclose confidential information and shall use it only in accordance with 
* the terms of the contract agreement you entered into with Taobao.com
*
*-------------------------------------------------------------------------------------------------*/

/**
 * @author wb-daichenjie
 * ��������
 */
public  final  class TBGlobalContext {

	private  String appuid;
    private	 ITBPlatformService tbService;
	private static TBGlobalContext tBWContext;

	public synchronized static TBGlobalContext getInstance(){
		if(tBWContext == null){
			tBWContext = new TBGlobalContext();
		}
		return tBWContext;
	} 

	public  String getAppUID() {
		return appuid;
	}

	public  void setAppUID(String appuid) {
		this.appuid = appuid;
	}
	
	public void setPlatformService(ITBPlatformService tbService){
		this.tbService = tbService;
	}
	
	public ITBPlatformService getPlatformService(){
		return this.tbService;
	}
}
