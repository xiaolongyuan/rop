package com.taobao.app;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.taobao.platformservice.ITBPlatformService;
import com.taobao.platformservice.ITBRemoteCallback;
import com.taobao.platformservice.TBAppInfo;
import com.taobao.platformservice.TBAppInfoParcelable;

public class MainActivity extends Activity implements Callback {

	private static final String TAG = "TBDemoClinet";
	// ���ϻ�������
	private static final String APPKEY = "12170061";
	private static final String APPSECRET = "fd05a753c73772f07124cf184a4cba72";
	private static final String TTID = "205200@tbdemo2.0_android1.6";

	private TBLoginInfo loginInfo = null;
	private String sid = "";

	private ITBPlatformService m_tbService;
	private String m_appUID;
	private Activity activity;

	private Button uvButton;
	private Button loginButton;

	public static final String USERAGENTSTR = "anclient";
	private static final int TAOBAOMSG_SHOW_UVTOAST = 1000;
	private static final int TAOBAOMSG_INPUTSTRING_ISNULL = 1001;

	private static final int TAOBAOMSG_LOGIN_SUCCESS = 2001;
	private static final int TAOBAOMSG_OTHER_LOGIN_SUCCESS = 2002;
	private static final int TAOBAOMSG_HAVE_LOGIN = 2003;
	private static final int TAOBAOMSG_LOGOUT = 2006;
	private static final int TAOBAOMSG_OTHER_LOGOUT = 2007;

	private Handler appHandler;
	private TextView textViewifdenglu;

	// �����Ի�������
	private AlertDialog dialog = null;

	/**
	 * dialog��dismiss����
	 */
	public void dismiss() {
		if (this.dialog != null) {
			this.dialog.dismiss();
		}
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// ���̨�����
		bindService(new Intent(ITBPlatformService.class.getName()),
				m_tbConnection, Context.BIND_AUTO_CREATE);

		this.activity = this;
		appHandler = new Handler(MainActivity.this);
		// ��ʼ��������ַ
		ImageButton m_btSearch = (ImageButton) this
				.findViewById(R.id.searchbutton);
		m_btSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// �����ֳ��Ȳ��ʿ�
				EditText textField = (EditText) findViewById(R.id.sechedit);
				String key = textField.getText().toString();
				if (!Tools.isEmpty(key)) {
					key = key.trim();
					if (key.length() == 0) {
						appHandler
								.sendEmptyMessage(TAOBAOMSG_INPUTSTRING_ISNULL);
						return;
					}
				}
				// �л���������
				Intent tempIntent = new Intent(MainActivity.this,
						SearchedList.class);
				Bundle tempBundle = new Bundle();
				tempBundle.putString("SEARCHED_KEY", key);
				tempIntent.putExtras(tempBundle);
				startActivity(tempIntent);
			}
		});

		// ��¼��ť
		loginButton = (Button) this.findViewById(R.id.login_button);
		loginButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				try {
					Log.v("MainActivity", "��¼");
					if (loginButton.getText().equals("��¼")) {
						m_tbService
								.doRequest("api=com.taobao.android.platformservice&action=login&appuid="
										+ m_appUID + "&data={}");
					} else if (loginButton.getText().equals("ע��")) {
						m_tbService
								.doRequest("api=com.taobao.android.platformservice&action=logout&appuid="
										+ m_appUID + "&data={}");
					}
				} catch (RemoteException e) {
					e.printStackTrace();
					return;
				}
			}
		});

		// UVͳ�ư�ť
		uvButton = (Button) this.findViewById(R.id.uv_button);
		uvButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				try {
					m_tbService
							.doRequest("api=com.taobao.android.platformservice&action=statistic&appuid="
									+ m_appUID);
					uvButton.setEnabled(false);
				} catch (RemoteException e) {
					e.printStackTrace();
					return;
				}
			}
		});

		textViewifdenglu = (TextView) this.findViewById(R.id.textviewdenglu);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// �˳�ʱ��ʾȷ���˳�
			showExitMessage("���Ƿ�Ҫ�˳��ͻ��ˣ�");
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * �˳�APP��ʾ
	 * 
	 * @param str
	 *            ��ʾ����
	 */
	private void showExitMessage(String str) {
		new AlertDialog.Builder(this)
				.setTitle("�˳�����")
				.setMessage(str)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialoginterface, int i) {
						finish();
					}
				})
				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialoginterface, int i) {

					}
				}).show();
	}

	@Override
	protected void onDestroy() {

		if (m_tbService != null) {
			try {
				// ���appע��
				m_tbService.removeApp(m_appUID);
			} catch (RemoteException e) {
				Log.v(TAG, "", e);
			}
		}

		// ��������
		unbindService(m_tbConnection);
		// ��������APP��Ϣ
		TBGlobalContext.getInstance().setAppUID(null);
		TBGlobalContext.getInstance().setPlatformService(null);
		super.onDestroy();
	}

	private ITBRemoteCallback.Stub m_tbCallback = new ITBRemoteCallback.Stub() {

		@Override
		public void OnResponse(String respjson) throws RemoteException {
			Log.v(TAG, "OnResponse : " + respjson);
			try {
				JSONObject json = new JSONObject(respjson);
				if (json.getString("action").equals("statistic")) {
					Message msg = new Message();
					msg.what = TAOBAOMSG_SHOW_UVTOAST;
					msg.obj = json.getString("ret");
					appHandler.sendMessage(msg);
				} else if (json.getString("action").equals("login")) {
					// ��Ϊ���յ���¼����Ӧ��ʱ��,��Ҫȡ����ǰ�����ĶԻ���
					MainActivity.this.dismiss();
					String s_sid = json.getString("sid");
					String token = json.getString("token");
					String nick = json.getString("nick");
					loginInfo = new TBLoginInfo();
					loginInfo.nick = nick;
					loginInfo.sid = s_sid;
					loginInfo.token = token;
					if (s_sid != null && s_sid.length() > 0) {
						String ret = json.getString("ret");
						if (ret.contains("������ز�Ʒ�Ѿ���¼�ɹ�")) {
							Message msg = new Message();
							msg.what = TAOBAOMSG_OTHER_LOGIN_SUCCESS;
							msg.obj = loginInfo;
							appHandler.sendMessage(msg);
						} else if (ret.contains("��¼�ɹ�")) {
							Message msg = new Message();
							msg.what = TAOBAOMSG_LOGIN_SUCCESS;
							msg.obj = loginInfo;
							appHandler.sendMessage(msg);

						} else if (ret.contains("�Ѿ���¼����")) {
							Message msg = new Message();
							msg.what = TAOBAOMSG_HAVE_LOGIN;
							msg.obj = loginInfo;
							appHandler.sendMessage(msg);
						}
					}
				} else if (json.getString("action").equals("logout")) {
					if (json.has("sid")) {
						MainActivity.this.dismiss();
						String s_sid = json.getString("sid");
						Log.v("MainActivity", "s_sid:" + s_sid + "  sid:"
								+ MainActivity.this.sid);
						String ret = json.getString("ret");
						if (ret.contains("�˳��ɹ�")) {
							Message msg = new Message();
							msg.what = TAOBAOMSG_LOGOUT;
							msg.obj = loginInfo;
							appHandler.sendMessage(msg);
						} else if (MainActivity.this.sid.equals(s_sid)) {
							String nick = "";
							if (json.has("nick")) {
								nick = json.getString("nick");
							}
							Log.v("MainActivity", "[Logout]");
							Message msg = new Message();
							msg.obj = nick;
							msg.what = TAOBAOMSG_OTHER_LOGOUT;
							appHandler.sendMessage(msg);
						}
					}
				}

			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		@Override
		public void startActivity(String packageName, String className,
				int iCallingPid, Bundle bundle) throws RemoteException {
			Log.v(TAG, "startActivity : " + packageName);
			Intent intent = new Intent(Intent.ACTION_MAIN, null);
			// �����̨���񴫵ݳ�����bundleΪnull��ʱ��
			if (bundle == null) {
				bundle = new Bundle();
			}
			// Log.v("bundle", bundle.toString());
			try {
				bundle.putInt("CallingPid", iCallingPid);
				intent.putExtras(bundle);
			} catch (Exception e) {
				e.printStackTrace();
			}

			intent.setClassName(packageName, className);
			activity.startActivity(intent);
		}
	};

	private ServiceConnection m_tbConnection = new ServiceConnection() {

		@Override
		public void onServiceDisconnected(ComponentName name) {
			Log.v(TAG, "onServiceDisconnected : " + name.toString());
			m_tbService = null;
		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			Log.v(TAG, "onServiceConnected");

			m_tbService = ITBPlatformService.Stub.asInterface(service);

			try {
				Log.v(TAG, "mCallback " + m_tbCallback.toString());
				// ʵ��һ��APPInfo����
				TBAppInfo appinfo = new TBAppInfo("com.taobao.tbdemoclinet",
						APPKEY, APPSECRET, TTID);
				// �����ɲ�ͬԶ��ͨѶ��ʹ�õĶ���
				TBAppInfoParcelable appinfoparcelable = new TBAppInfoParcelable(
						appinfo);
				// ע��APP�ͻ���
				m_appUID = m_tbService.registerApp(appinfoparcelable,
						m_tbCallback);
				Log.v(TAG, "m_appUID " + m_appUID);
				// �洢���ص���Ϣ
				TBGlobalContext.getInstance().setAppUID(m_appUID);
				TBGlobalContext.getInstance().setPlatformService(m_tbService);
			} catch (RemoteException e) {
				Log.v(TAG, "", e);
			}

		}
	};

	private void showToast(String str) {
		Toast toast;
		toast = Toast.makeText(activity, "���ͳ�ƣ�" + str, 3000);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.show();
		uvButton.setEnabled(true);
	}

	@Override
	public boolean handleMessage(Message msg) {
		switch (msg.what) {

		case TAOBAOMSG_SHOW_UVTOAST: {
			showToast((String) msg.obj);
			return true;
		}
			// ����������Ϊ�գ����ߴ��ո�
		case TAOBAOMSG_INPUTSTRING_ISNULL: {
			new AlertDialog.Builder(this)
					.setTitle("��ʾ")
					.setMessage("������ؼ��֣�")
					.setPositiveButton("ȷ��",
							new DialogInterface.OnClickListener() {
								public void onClick(
										DialogInterface dialoginterface, int i) {

								}
							}).show();
			return true;
		}
		case TAOBAOMSG_LOGIN_SUCCESS:

			if (!Tools.isEmpty(loginInfo.getNick())) {
				MainActivity.this.sid = loginInfo.sid;
				textViewifdenglu.setText("��ӭ�㣺" + loginInfo.getNick() + "��");
				loginButton.setText("ע��");
			}

			return true;

		case TAOBAOMSG_HAVE_LOGIN:
		case TAOBAOMSG_OTHER_LOGIN_SUCCESS:
			if (loginInfo != null) {
				new AlertDialog.Builder(MainActivity.this)
						.setTitle("��¼")
						.setMessage("�Ƿ�ʹ�� " + loginInfo.getNick() + " ��¼!")
						.setPositiveButton("��",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {
										MainActivity.this.sid = loginInfo.sid;
										textViewifdenglu.setText("��ӭ�㣺" + loginInfo.getNick() + "��");
										loginButton.setText("ע��");
										dialog.dismiss();
									}
								})
						.setNegativeButton("��",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {
										// ע����ǰ�û�
										// ��¼
										try {
											MainActivity.this.m_tbService
													.doRequest("api=com.taobao.android.platformservice&action=logout&appuid="
															+ m_appUID);
											MainActivity.this.m_tbService
													.doRequest("api=com.taobao.android.platformservice&action=login&appuid="
															+ m_appUID);
										} catch (RemoteException e) {
											e.printStackTrace();
										}
									}
								}).show();

			}
			break;
		case TAOBAOMSG_LOGOUT:
			MainActivity.this.sid = "";
			textViewifdenglu.setText("����û�е�¼��");
			loginButton.setText("��¼");
			return true;
		case TAOBAOMSG_OTHER_LOGOUT:
			String nick = (String) msg.obj;
			new AlertDialog.Builder(MainActivity.this)
					.setTitle("�ǳ���ʾ")
					.setMessage(nick + "�Ѿ��ڱ���������Ӧ����ͬ���ǳ�!")
					.setPositiveButton("�ر�",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									dialog.dismiss();
								}
							}).show();
			MainActivity.this.sid = "";
			textViewifdenglu.setText("����û�е�¼��");
			loginButton.setText("��¼");
			break;
		}
		return false;

	}

	// ��¼��2���������棨��¼������л�������
	protected void onRestart() {
		super.onRestart();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
}