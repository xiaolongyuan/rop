package com.taobao.app;


import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.taobao.platformservice.ITBPlatformService;
import com.taobao.platformservice.ITBRemoteCallback;
import com.taobao.platformservice.TBAppInfo;
import com.taobao.platformservice.TBAppInfoParcelable;


public class TBDemoClient extends Activity{
	
	private static final String TAG = "TBDemoClinet";

	//���ϻ�������
	private static final String  APPKEY = "12170061";
	private static final  String APPSECRET = "fd05a753c73772f07124cf184a4cba72";
	
	//���Ի�������
	//private static final String APPKEY = "4272";;
    //private static final  String APPSECRET= "0ebbcccfee18d7ad1aebc5b135ffa906";
	
	private static final  String TTID = "205200@tbdemo1.0_android1.6";
    
    private ITBPlatformService m_tbService;
    
    private String m_appUID;
    
    
    private Activity activity;
	private TextView textViewifdenglu;
	
	private Button uvButton;
	
	Integer lock = 0;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        this.activity = this;
        bindService(new Intent(ITBPlatformService.class.getName()), m_tbConnection, Context.BIND_AUTO_CREATE);
    
		textViewifdenglu = (TextView) this.findViewById(R.id.textviewdenglu);
		
		uvButton = (Button) this.findViewById(R.id.uv_button);
		uvButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
					try {		

		                m_tbService.doRequest("api=com.taobao.platformservice.statisticsrv&action=checkin&appuid="+m_appUID);
						
		                uvButton.setEnabled(false);
		                
					} catch (RemoteException e) {
						e.printStackTrace();
			            return;
					}
			}
		});
		
		
		Button loginButton = (Button) this.findViewById(R.id.login_button);
		loginButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
					try {		

						m_tbService.doRequest("api=com.taobao.android.platformservice&action=login&appuid="+m_appUID+"&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
						
					} catch (RemoteException e) {
						e.printStackTrace();
			            return;
					}
				
			}
		});
		
		Button  paybutton = (Button )this.findViewById(R.id.test_button);
		paybutton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				try {		
					m_tbService.doRequest("api=com.taobao.platformservice.paysrv&action=pay&appuid="+m_appUID+"&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
					
				} catch (RemoteException e) {
					e.printStackTrace();
					return;
				}
			}
		});
		
		Button testButton = (Button) this.findViewById(R.id.test_button);
		testButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
//					try {		
//
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=one&appuid=12345&data={\"usename\":\"taobao1234\",\"password\":\"taobao1234\"}");
//					} catch (RemoteException e) {
//						e.printStackTrace();
//			            return;
//					}
				try {		
					
	                m_tbService.doRequest("api=com.taobao.android.platformservice&action=detail&appuid="+m_appUID +"&data={\"itemid\":\"9317389879\",\"tab\":\"2\"}");
	                //m_tbService.doRequest("api=com.taobao.android.platformservice&action=logout&appuid="+m_appUID);

				} catch (RemoteException e) {
					e.printStackTrace();
		            return;
				}
				
			}
		});
		Button avaliable_service = (Button) this.findViewById(R.id.avaliable_service);
		avaliable_service.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
					try {		

		                m_tbService.doRequest("api=com.taobao.daichenjie.test&action=testerror&appuid="+m_appUID);
						
					} catch (RemoteException e) {
						e.printStackTrace();
			            return;
					}
			}
		});
		
		Button pay_btn = (Button) this.findViewById(R.id.pay_button);
		pay_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
					try {		
		                //m_tbService.doRequest("api=com.taobao.android.platformservice&action=pay&appuid="+m_appUID+"&data={\"externtoken\":\"taobao1234\",\"partnerid\":\"PARTNER_TAOBAO_ORDER\",\"tradeno\":\"taobao1234\"}");
						m_tbService.doRequest("api=com.taobao.android.platformservice&action=logout&appuid="+m_appUID);
					} catch (RemoteException e) {
						e.printStackTrace();
			            return;
					}
			}
		});
		
    }

    @Override
    protected void onDestroy() {
        if(m_tbService!=null){
            try {
            	m_tbService.removeApp(m_appUID);
                
            } catch (RemoteException e) {
                Log.v(TAG, "", e);
            }
        }

        unbindService(m_tbConnection);
        super.onDestroy();
    }

    private ITBRemoteCallback.Stub m_tbCallback = new ITBRemoteCallback.Stub() {

		@Override
		public void OnResponse(String respjson) throws RemoteException {
			// TODO Auto-generated method stub
			Log.v(TAG, "OnResponse : " + respjson);
			
			try {
				JSONObject jobj = new JSONObject(respjson);
				if(jobj.getString("action").equals("checkin"))
				{
					Message msg = new Message();
					msg.what = 1;
					msg.obj = jobj.getString("ret");
					m_tbHandler.sendMessage(msg);
				}
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void startActivity(String packageName, String className,
				int iCallingPid, Bundle bundle) throws RemoteException {
			// TODO Auto-generated method stub
			Log.v(TAG, "startActivity : " + packageName);
			
			Intent intent = new Intent(Intent.ACTION_MAIN, null);
			Log.v("bundle", bundle.toString());
			if( bundle == null ){
				bundle = new Bundle();
			}
				
			
			try
			{
				bundle.putInt("CallingPid", iCallingPid);
				intent.putExtras(bundle);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			intent.setClassName(packageName, className);
			activity.startActivity(intent);
		}
    };
    
    private ServiceConnection m_tbConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
        	Log.v(TAG, "onServiceDisconnected : " + name.toString());
            m_tbService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.v(TAG, "onServiceConnected");
            
            m_tbService = ITBPlatformService.Stub.asInterface(service);
	     	
            try {
	   	    	   
	   	    	Log.v(TAG, "mCallback "+ m_tbCallback.toString());
	   	    	TBAppInfo appinfo = new TBAppInfo("com.taobao.tbdemoclinet", APPKEY, APPSECRET, TTID);
	   	    	TBAppInfoParcelable appinfoparcelable = new TBAppInfoParcelable(appinfo);
	   	    	
	   			m_appUID = m_tbService.registerApp(appinfoparcelable, m_tbCallback);           
	   			Log.v(TAG, "m_appUID "+ m_appUID);
	   	    	
	   	    } catch (RemoteException e) {
	   	        Log.v(TAG, "", e);
	   	    }

         }
    };
    
    
    private void showToast(String str)
    {
		Toast toast;
		toast = Toast.makeText(activity,"���ͳ�ƣ�"+str,3000);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.show();
		
		uvButton.setEnabled(true);
    }
    
    private final Handler m_tbHandler = new Handler() {
        @Override public void handleMessage(Message msg) {
            switch (msg.what) {
                
                case 1: {
                	showToast((String) msg.obj);
                } break;
                
                default:
                    super.handleMessage(msg);
            }
        }
    };
    
}